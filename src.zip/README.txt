In order to run OCamlChess, simply do

cs3110 compile app.ml
cs3110 run app.ml