open Chessmodel


let b:board = make_init_board ()

